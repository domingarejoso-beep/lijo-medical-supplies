import { LijoLanding } from "@/components/lijo-landing"

export default function HomePage() {
  return <LijoLanding />
}
