import type { Metadata, Viewport } from "next"
import { Inter, Poppins } from "next/font/google"
import "./globals.css"
import { pageDescription, pageTitle } from "@/config/lijo"

const inter = Inter({ variable: "--font-inter", subsets: ["latin"], display: "swap" })
const poppins = Poppins({ variable: "--font-poppins", subsets: ["latin"], weight: ["400", "500", "600", "700"], display: "swap" })

export const metadata: Metadata = {
  title: pageTitle,
  description: pageDescription,
  applicationName: "LIJO Medical Supplies",
  openGraph: {
    title: pageTitle,
    description: pageDescription,
    type: "website",
    locale: "en_PH",
  },
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#f7faf9",
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en-PH"><body className={`${inter.variable} ${poppins.variable}`}>{children}</body></html>
}
