"use client"

import { useState, type FormEvent } from "react"
import { ArrowUpRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { formLabels, formPlaceholders, whatsappFormUrl, whatsappIntro } from "@/config/lijo"

export function QuoteForm() {
  const [sent, setSent] = useState(false)

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const fields = [
      ["Name", formData.get("name")],
      ["Organization", formData.get("organization")],
      ["Email", formData.get("email")],
      ["Mobile", formData.get("mobile")],
      ["City / province", formData.get("location")],
      ["Products needed", formData.get("products")],
      ["Message", formData.get("message")],
    ].filter(([, value]) => typeof value === "string" && value.trim())
    const message = `${whatsappIntro}\n\n${fields.map(([label, value]) => `${label}: ${String(value).trim()}`).join("\n")}`
    window.open(`${whatsappFormUrl}${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer")
    setSent(true)
  }

  return <form className="quote-form" onSubmit={handleSubmit} aria-label="Request a quote from LIJO">
    <div className="form-grid">
      <label className="form-field"><span>{formLabels.name} <i>*</i></span><input autoComplete="name" name="name" placeholder="Your name" required /></label>
      <label className="form-field"><span>{formLabels.organization}</span><input autoComplete="organization" name="organization" placeholder={formPlaceholders.organization} /></label>
      <label className="form-field"><span>{formLabels.email} <i>*</i></span><input type="email" autoComplete="email" name="email" placeholder="you@example.com" required /></label>
      <label className="form-field"><span>{formLabels.mobile} <i>*</i></span><input type="tel" autoComplete="tel" name="mobile" placeholder="09XX XXX XXXX" required /></label>
      <label className="form-field form-field-wide"><span>{formLabels.location} <i>*</i></span><input autoComplete="address-level2" name="location" placeholder="City or province" required /></label>
      <label className="form-field form-field-wide"><span>{formLabels.products} <i>*</i></span><textarea name="products" rows={3} placeholder={formPlaceholders.products} required /></label>
      <label className="form-field form-field-wide"><span>{formLabels.message}</span><textarea name="message" rows={3} placeholder={formPlaceholders.message} /></label>
    </div>
    <Button className="button form-submit" type="submit">{sent ? "Open WhatsApp again" : "Continue to WhatsApp"}<ArrowUpRight aria-hidden="true" data-icon="inline-end" /></Button>
    <p className="form-note">Your details are included in the WhatsApp message. Review and send it there.</p>
    {sent && <p className="form-success" role="status">Your message is ready in WhatsApp. Please review and send it to LIJO.</p>}
  </form>
}
