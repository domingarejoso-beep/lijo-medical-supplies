export const siteConfig = {
  brand: {
    name: 'LIJO',
    fullName: 'LIJO Medical Supplies',
    tagline: 'Care, supplied with confidence.',
    description:
      'Trusted supplier for hospitals, clinics, and pharmacies across the Philippines.',
  },
  contact: {
    phone: '0929 346 8977',
    phoneInternational: '+639293468977',
    email: 'jlmedicalsupplies@gmail.com',
    address: 'Business address available upon request',
    whatsapp: 'https://wa.me/639293468977',
    viber: 'viber://chat?number=%2B639293468977',
  },
  navigation: [
    { label: 'Products', href: '#products' },
    { label: 'Why LIJO', href: '#why-lijo' },
    { label: 'Delivery', href: '#delivery' },
    { label: 'About', href: '#about' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Contact', href: '#contact' },
  ],
  categories: [
    {
      number: '01',
      name: 'Personal protective equipment',
      description: 'Masks, gloves, gowns, and everyday protective essentials.',
      icon: 'shield',
    },
    {
      number: '02',
      name: 'Diagnostic devices',
      description: 'Thermometers, blood pressure monitors, and glucometers.',
      icon: 'pulse',
    },
    {
      number: '03',
      name: 'Wound care & first aid',
      description: 'Dressings, bandages, and thoughtfully chosen first-aid basics.',
      icon: 'heart',
    },
    {
      number: '04',
      name: 'Mobility & home care',
      description: 'Wheelchairs, walkers, and practical home-care equipment.',
      icon: 'mobility',
    },
    {
      number: '05',
      name: 'Disposables & consumables',
      description: 'Syringes, gauze, IV supplies, and day-to-day essentials.',
      icon: 'boxes',
    },
    {
      number: '06',
      name: 'Clinic & hospital equipment',
      description: 'Dependable equipment for clinical and care environments.',
      icon: 'clinic',
    },
  ],
  faqs: [
    {
      question: 'Is there a minimum order requirement?',
      answer:
        'Order quantities can vary by product. Send us your list and we\'ll confirm availability, any minimums, and the best quote for your needs.',
    },
    {
      question: 'Do you ship nationwide, and how long does delivery take?',
      answer:
        'Yes. We coordinate deliveries to Luzon, Visayas, and Mindanao. Timing depends on the destination and item availability, and we\'ll share an estimate with your quote.',
    },
    {
      question: 'What payment methods do you accept?',
      answer:
        'Payment details are confirmed with your quotation. Prices and payment amounts are provided in Philippine pesos (₱).',
    },
    {
      question: 'How can I confirm product authenticity?',
      answer:
        'Ask us about a specific item, its manufacturer, and the available product documentation. We\'ll share the relevant details before you place an order.',
    },
    {
      question: 'Can I request pricing for a bulk order?',
      answer:
        'Absolutely. Include your estimated quantities and delivery location in your inquiry so we can prepare a quote tailored to your order.',
    },
  ],
} as const;
