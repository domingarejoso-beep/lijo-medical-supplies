export const site = {
  brand: "LIJO Medical Supplies",
  shortName: "LIJO",
  email: "jlmedicalsupplies@gmail.com",
  phone: "0929 346 8977",
  phoneE164: "+639293468977",
  address: "Philippines · Address details available upon request",
  whatsapp: "https://wa.me/639293468977",
  viber: "viber://chat?number=%2B639293468977",
  image: "/images/lijo-medical-supplies.png",
  nav: [
    { label: "Products", href: "#products" }, { label: "Why LIJO", href: "#why-lijo" },
    { label: "Delivery", href: "#delivery" }, { label: "About", href: "#about" },
    { label: "FAQ", href: "#faq" }, { label: "Contact", href: "#contact" },
  ],
  categories: [
    { icon: "ShieldCheck", title: "Personal protective equipment", text: "Masks, gloves, gowns, and everyday protective essentials." },
    { icon: "Activity", title: "Diagnostic devices", text: "Thermometers, blood pressure monitors, and glucometers." },
    { icon: "HeartPulse", title: "Wound care & first aid", text: "Thoughtful essentials for first aid and routine wound care." },
    { icon: "Accessibility", title: "Mobility & home care", text: "Wheelchairs, walkers, beds, and home care equipment." },
    { icon: "Package", title: "Disposables & consumables", text: "Syringes, gauze, IV supplies, and daily-use essentials." },
    { icon: "Stethoscope", title: "Clinic & hospital equipment", text: "A range of equipment for care settings of every size." },
  ],
  benefits: [
    { icon: "BadgeCheck", title: "Quality-minded selection", text: "Dependable medical supplies and clear product information." },
    { icon: "Wallet", title: "Competitive quotations", text: "Quotes tailored to your product list and order size." },
    { icon: "Truck", title: "Nationwide delivery", text: "Delivery coordination across Luzon, Visayas, and Mindanao." },
    { icon: "MessagesSquare", title: "Responsive support", text: "Talk directly with our team about availability and orders." },
  ],
  faqs: [
    { q: "Is there a minimum order?", a: "Minimums can vary by product. Send us the items you need and we’ll confirm any minimums in your quote." },
    { q: "Do you deliver nationwide, and how long does shipping take?", a: "We coordinate deliveries across Luzon, Visayas, and Mindanao. Timing depends on destination, product availability, and courier; we’ll confirm an estimate with your quote." },
    { q: "What payment methods do you accept?", a: "Payment options and terms are confirmed with each quotation. Prices and payment details are provided in Philippine pesos (₱)." },
    { q: "Are your products authentic?", a: "We provide product details and available documentation during the quotation process. Contact us about a specific product if you need more information." },
    { q: "Can I request bulk pricing?", a: "Yes. Include the products and quantities you’re considering, and we’ll prepare a quote for your order." },
  ],
} as const

export const hero = {
  eyebrow: "A reliable partner for your supply needs",
  title: "Quality Medical Supplies, Delivered Nationwide",
  subtitle: "Trusted supplier for hospitals, clinics, and pharmacies across the Philippines.",
  description: "From everyday essentials to equipment, LIJO helps you source supplies with responsive support and delivery coordination across Luzon, Visayas, and Mindanao.",
  imageAlt: "A selection of medical supplies, diagnostic tools, and protective equipment",
}
export const trust = ["Nationwide delivery", "Quality-assured products", "Bulk and retail orders", "Responsive support"]
export const regions = [
  { name: "Luzon", note: "Metro Manila and provinces" },
  { name: "Visayas", note: "Island communities" },
  { name: "Mindanao", note: "Cities and provinces" },
]
export const steps = [
  { number: "01", title: "Send your inquiry", text: "Tell us what you need, including product names and quantities." },
  { number: "02", title: "Get your quote", text: "We’ll reply with availability, pricing, and delivery details." },
  { number: "03", title: "Receive your order", text: "Confirm your order and coordinate delivery anywhere in the Philippines." },
]
export const audiences = [
  { title: "Hospitals & clinics", text: "For care teams sourcing essentials for their facilities." },
  { title: "Pharmacies & resellers", text: "For businesses looking for a responsive supply partner." },
  { title: "LGUs & organizations", text: "For teams coordinating community supply needs." },
  { title: "Home care & individuals", text: "For families arranging everyday care essentials." },
]
export const story = "LIJO Medical Supplies serves hospitals, clinics, pharmacies, resellers, LGUs, and individuals looking for medical essentials. We help customers find the right products, get a clear quotation, and coordinate delivery to their location."
export const mission = "To make sourcing dependable medical essentials simpler for care providers, businesses, and families throughout the Philippines."
export const pageTitle = "LIJO Medical Supplies | Quality Supplies, Delivered Nationwide"
export const pageDescription = "Quality medical supplies for hospitals, clinics, pharmacies, resellers, LGUs, and families across the Philippines. Request a quote from LIJO Medical Supplies."
export const footerCredit = "Website designed by Dominga Rejoso"
export const footerDescription = "Medical supplies and responsive support, wherever care happens."
export const copyright = `© ${new Date().getFullYear()} LIJO Medical Supplies. All rights reserved.`
export const whatsappIntro = "Hello LIJO Medical Supplies, I’d like to request a quote."
export const formPrivacy = "Your inquiry opens in WhatsApp for your review before sending."
export const testimonialsDisclosure = "We don’t publish customer quotes without permission. We’d be glad to connect with you directly to discuss your needs."
export const shippingDisclosure = "Product availability, pricing, and delivery timing are confirmed when you request a quote."
export const whatsappUrl = site.whatsapp
export const emailUrl = `mailto:${site.email}`
export const phoneUrl = `tel:${site.phoneE164}`
export const whatsappFormUrl = `${site.whatsapp}?text=`
export const formLabels = { name: "Name", organization: "Organization", email: "Email", mobile: "Mobile number", location: "City / province", products: "Products needed", message: "Message" }
export const formPlaceholders = { organization: "Hospital, clinic, business, or optional", products: "Products and quantities you’re looking for", message: "Anything else we should know?" }
export const floatingChat = [
  { label: "Viber", href: site.viber, tooltip: "Chat with us on Viber", aria: "Chat with LIJO on Viber" },
  { label: "WhatsApp", href: site.whatsapp, tooltip: "Chat with us on WhatsApp", aria: "Chat with LIJO on WhatsApp" },
]
