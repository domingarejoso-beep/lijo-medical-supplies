export const siteConfig = {
  brand: 'LIJO Medical Supplies',
  shortBrand: 'LIJO',
  headline: 'Quality Medical Supplies, Delivered Nationwide',
  subheadline:
    'A dependable source for hospitals, clinics, pharmacies, resellers, and home care across the Philippines.',
  contact: {
    phoneDisplay: '0929 346 8977',
    phoneInternational: '+639293468977',
    email: 'jlmedicalsupplies@gmail.com',
    address: '[Business address available upon request]',
    whatsapp: 'https://wa.me/639293468977',
    viber: 'viber://chat?number=%2B639293468977',
  },
  nav: [
    { label: 'Products', href: '#products' },
    { label: 'Why LIJO', href: '#why-lijo' },
    { label: 'Delivery', href: '#delivery' },
    { label: 'About', href: '#about' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Contact', href: '#contact' },
  ],
  categories: [
    {
      title: 'Personal protective equipment',
      description: 'Masks, gloves, gowns, and everyday protective essentials.',
      icon: 'shield',
      number: '01',
    },
    {
      title: 'Diagnostic devices',
      description: 'Thermometers, blood pressure monitors, and glucometers.',
      icon: 'activity',
      number: '02',
    },
    {
      title: 'Wound care & first aid',
      description: 'Practical supplies for first aid and routine wound care.',
      icon: 'heart',
      number: '03',
    },
    {
      title: 'Mobility & home care',
      description: 'Wheelchairs, walkers, hospital beds, and home care aids.',
      icon: 'accessibility',
      number: '04',
    },
    {
      title: 'Disposables & consumables',
      description: 'Syringes, gauze, IV supplies, and daily-use essentials.',
      icon: 'package',
      number: '05',
    },
    {
      title: 'Clinic & hospital equipment',
      description: 'Equipment and essentials for healthcare facilities.',
      icon: 'building',
      number: '06',
    },
  ],
  faqs: [
    {
      question: 'Is there a minimum order requirement?',
      answer:
        'Order requirements can vary by product. Send us the items and quantities you need, and we will confirm the options in your quote.',
    },
    {
      question: 'Do you ship nationwide, and how long does delivery take?',
      answer:
        'We coordinate deliveries to Luzon, Visayas, and Mindanao. Delivery timelines depend on your location, item availability, and courier; we will share an estimate with your quotation.',
    },
    {
      question: 'What payment methods do you accept?',
      answer:
        'Payment arrangements are confirmed during quotation. All quoted prices and payment details are provided in Philippine pesos (₱).',
    },
    {
      question: 'How do you ensure product authenticity?',
      answer:
        'Product specifications and available documentation can be discussed during the inquiry process. Please let us know if your organization has particular requirements.',
    },
    {
      question: 'Can I request bulk pricing?',
      answer:
        'Yes. Include the products and quantities you are considering, and our team can prepare a quotation for your order.',
    },
  ],
} as const
