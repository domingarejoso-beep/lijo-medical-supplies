export const lijoConfig = {
  brand: {
    name: 'LIJO',
    fullName: 'LIJO Medical Supplies',
    tagline: 'Your partner in better-prepared care.',
  },
  contact: {
    phoneDisplay: '0929 346 8977',
    phoneInternational: '+639293468977',
    phoneDigits: '639293468977',
    email: 'jlmedicalsupplies@gmail.com',
    address: 'Business address available upon request',
  },
  links: {
    whatsapp: 'https://wa.me/639293468977',
    viber: 'viber://chat?number=%2B639293468977',
  },
  navigation: [
    { label: 'Products', href: '#products' },
    { label: 'Why LIJO', href: '#why-lijo' },
    { label: 'Delivery', href: '#delivery' },
    { label: 'About', href: '#about' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Contact', href: '#contact' },
  ],
  categories: [
    {
      title: 'Personal protective equipment',
      description: 'Masks, gloves, gowns, and everyday protective essentials.',
      icon: 'shield',
    },
    {
      title: 'Diagnostic devices',
      description: 'Thermometers, BP monitors, glucometers, and more.',
      icon: 'diagnostic',
    },
    {
      title: 'Wound care & first aid',
      description: 'Practical essentials for first-aid kits and care settings.',
      icon: 'care',
    },
    {
      title: 'Mobility & home care',
      description: 'Wheelchairs, walkers, beds, and home-care support.',
      icon: 'mobility',
    },
    {
      title: 'Disposables & consumables',
      description: 'Syringes, gauze, IV supplies, and daily-use items.',
      icon: 'supplies',
    },
    {
      title: 'Clinic & hospital equipment',
      description: 'Equipment and essentials for care teams and facilities.',
      icon: 'equipment',
    },
  ],
  faqs: [
    {
      question: 'Is there a minimum order?',
      answer: "Order requirements can depend on the products you need. Send us your list and quantities, and we’ll confirm the best available options for your order.",
    },
    {
      question: 'Do you ship nationwide, and how long does delivery take?',
      answer: "We coordinate deliveries across Luzon, Visayas, and Mindanao. Delivery timelines vary by destination and product availability; we’ll include an estimate with your quote.",
    },
    {
      question: 'What payment methods do you accept?',
      answer: 'Payment options and quoted prices in Philippine pesos (₱) are confirmed with your order details. Our team will share the applicable payment instructions with your quotation.',
    },
    {
      question: 'How can I check product authenticity and specifications?',
      answer: 'Ask us for the available product details, specifications, and supporting documentation for the items in your inquiry before confirming an order.',
    },
    {
      question: 'Can I request bulk pricing?',
      answer: "Yes. Include the products and quantities you’re considering in your inquiry so we can prepare a quote based on your requirements.",
    },
  ],
} as const
